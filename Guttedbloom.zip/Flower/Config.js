import {@SwitchProperty, @Vigilant} from '../Vigilance/index';

@Vigilant("Flower", "Flower", {
    getCategoryComparator: () => (a, b) => {
        const categories = ["General"];
        return categories.indexOf(a.name) - categories.indexOf(b.name);
    }
})
class Config {
    constructor() {
        this.initialize(this)
    }
    @SwitchProperty({
        name: "Item Price Lore",
        description: "Shows the lowest BIN or bazaar buy and sell prices in every item's lore.",
        category: "General",
        subcategory: "Price Info"
    })
    itemPriceLore = false;

    @SwitchProperty({
        name: "Item Value Lore",
        description: "Shows the item's value in the bottom of the item's lore. This is different from the price info as it takes into account upgrades (Recombs, scrolls, enchants, stars etc).",
        category: "General",
        subcategory: "Price Info"
    })
    itemValueLore = false;

    @SwitchProperty({
        name: "Terminal Tracker",
        description: "Keeps track of how many terminals, devices and levers each player did.",
        category: "General",
        subcategory: "Terminals"
    })
    terminalTracker = false;
}
export default new Config()