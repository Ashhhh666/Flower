import Config from "./Config"
import "./features/ItemPriceLore"
import "./features/ItemValueOverlay"
import "./features/TermimalTracker"

register("command", Config.openGUI).setName("flower")