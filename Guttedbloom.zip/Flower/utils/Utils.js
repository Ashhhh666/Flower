import PogObject from "../../PogData/index"

export const prefix = "&5[&dFlower&5]&r"
export const data = new PogObject("Flower", {
    itemValueOverlay: {
        x: 0,
        y: 0,
        scale: 1
    },
}, "data/data.json")